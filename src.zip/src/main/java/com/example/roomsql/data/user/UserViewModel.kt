package com.example.roomsql.data.user

import android.R.attr.password
import android.app.Application
import android.service.autofill.UserData
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.roomsql.data.database.AppDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class UserViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: UserRepository
    val allUsers: Flow<List<UsersData>>


    init {
        val userDao = AppDatabase.Companion.getDatabase(application).userDao()
        repository = UserRepository(userDao)
        allUsers = repository.allUsers
    }

    fun insertUser(
        username: String,
        email: String,
        password: String,
        confirmPassword: String
    ) = viewModelScope.launch {
        repository.insert(
            UsersData(
                username = username,
                email = email,
                password = password,
                confirmPassword = confirmPassword
            )
        )
    }

    fun updateUser(user: UsersData) = viewModelScope.launch {
        repository.update(user)
    }

    fun deleteUser(user: UsersData) = viewModelScope.launch {
        repository.delete(user)
    }

    fun loginUser(username: String, password: String, onResult: (UsersData?) -> Unit) {
        viewModelScope.launch {
            val user = repository.login(username, password)
            onResult(user)//return true if login success
        }
    }
}

class UserViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UserViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return UserViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

package com.example.roomsql.data.user

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "table_users_data")
data class UsersData(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val username: String,
    val email: String,
    val password: String,
    val confirmPassword: String

)
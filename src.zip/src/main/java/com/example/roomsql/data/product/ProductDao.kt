package com.example.roomsql.data.product

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow


//Create 1
/**
 * 💡 DAO: The Data Access Object.
 * TEACHING POINT: The DAO is an interface where you define all the functions
 * you need to interact with your database (e.g., insert, get,update and delete).
 * Room generates all the code for these functions automatically.
 */
@Dao
interface ProductDao {
    @Insert
    suspend fun insert(product: ProductDetails)

    @Update
    suspend fun update(product: ProductDetails)

    @Delete
    suspend fun delete(product: ProductDetails)

    @Query("SELECT * FROM table_product_detail ORDER BY id ASC")
    fun getAllProducts(): Flow<List<ProductDetails>>
}




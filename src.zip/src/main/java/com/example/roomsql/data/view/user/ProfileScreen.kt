package com.example.roomsql.data.view.user

import android.R.attr.onClick
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.roomsql.data.user.UserViewModel
import com.example.roomsql.data.view.main.MainActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(navController: NavController, viewModel: UserViewModel) {


    val userName = MainActivity.USERNAME
    val userEmail = MainActivity.EMAIL

    val coroutineScope = rememberCoroutineScope()
    val shouldShowDialog = remember { mutableStateOf(false) }



    if (shouldShowDialog.value) {
        AlertDialogMenuScreen(
            navController = navController,
            shouldShowDialog = shouldShowDialog
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top
    ) {

        Text(
            text = "ProfileScreen"
        )


        Column(
            modifier = Modifier
                .padding(16.dp)
        )
        {

            Text(text = "ProfileScreen")
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Hi $userName", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Email: $userEmail")
        }
        Button(
            onClick = {
                coroutineScope.launch {
                    delay(500)
                    shouldShowDialog.value = true
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp)
        ) {

            Text(
                text = "Back to Login Screen",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
        }

        //todo profileUi 1-> fullName 2-> email
        //todo query from database
        // todo show in profileUi

    }
    BackHandler(enabled = true) {
        shouldShowDialog.value = true
    }

}

@Composable
fun AlertDialogMenuScreen(
    navController: NavController,
    shouldShowDialog: MutableState<Boolean>
) {
    if (shouldShowDialog.value) {
        AlertDialog(
            onDismissRequest = {
                shouldShowDialog.value = false
            },
            title = { Text(text = "Alert") },
            text = { Text(text = "Going back to main screen?") },
            confirmButton = {
                Button(
                    onClick = {
                        shouldShowDialog.value = false
//                        navController.popBackStack()
                        navController.navigate("ProductScreen") {
                            popUpTo(navController.graph.startDestinationId) {
                                inclusive = true
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                    shape = RoundedCornerShape(32.dp),
                )
                {
                    Text(
                        text = "Confirm",
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            },
            dismissButton = {
                Button(
                    onClick = {
                        shouldShowDialog.value = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                    shape = RoundedCornerShape(32.dp),
                ) {
                    Text(
                        text = "Dismiss",
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }

        )
    }
}



package com.example.roomsql.data.payment

import kotlinx.coroutines.flow.Flow

class PaymentRepository(private val paymentDao: PaymentDao) {
    val allPayments: Flow<List<PaymentRecords>> = paymentDao.getAllPayments()

    suspend fun insert(payment: PaymentRecords) {
        paymentDao.insert(payment)
    }

    suspend fun update(payment: PaymentRecords) {
        paymentDao.update(payment)
    }

    suspend fun delete(payment: PaymentRecords) {
        paymentDao.delete(payment)
    }
}

package com.example.roomsql.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.roomsql.data.payment.PaymentDao
import com.example.roomsql.data.payment.PaymentRecords
import com.example.roomsql.data.product.ProductDao
import com.example.roomsql.data.product.ProductDetails
import com.example.roomsql.data.user.UsersData
import com.example.roomsql.data.user.UserDao

@Database(
    entities = [UsersData::class, ProductDetails::class, PaymentRecords::class], // home page new offers / RS(recommender system )
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun userDao(): UserDao
    abstract fun paymentDao(): PaymentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

/***
 * Room DB Purpose
 * Becomes the primary source of truth after initial load.
 *
 * All insert, update, delete operations happen in Room.
 *
 * UI reflects live data from Room via Flow<List<...>>.
 */


/*** command: tree ./app/src/main/java/com/example/roomsql(or app name)
 * com.example.roomsql
 * ├── data
 * │   ├── database       → AppDatabase or MainDatabase
 * │   ├── payment        → PaymentEntity, DAO, Repository, ViewModel
 * │   ├── product        → ProductEntity, DAO, Repository, ViewModel
 * │   ├── user           → UserEntity, DAO, Repository, ViewModel
 * │   └── view           → DeleteConfirmationDialog.kt,EditProductDialog.kt,MainActivity,ProductCard.kt,ProductScreen.kt
 * ├── json               → JsonLoader for initial data
 * └── ui
 *     └── theme          → Contains UI files (but should be split)
 */
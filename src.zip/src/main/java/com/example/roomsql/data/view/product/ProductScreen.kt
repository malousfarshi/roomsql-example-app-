package com.example.roomsql.data.view.product

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.Red
import androidx.compose.ui.graphics.Color.Companion.White
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import androidx.room.PrimaryKey
import com.example.roomsql.data.product.ProductDetails
import com.example.roomsql.data.product.ProductViewModel
import com.example.roomsql.data.view.user.ProfileScreen
import kotlinx.coroutines.launch

@Composable
fun ProductScreen(navController: NavController, viewModel: ProductViewModel) {

    val products by viewModel.allProducts.collectAsState(initial = emptyList())

    var newName by remember { mutableStateOf("") }
    var newPrice by remember { mutableStateOf("") }
    var newDescription by remember { mutableStateOf("") }

    var showEditDialog by remember { mutableStateOf(false) }
    var productToEdit by remember { mutableStateOf<ProductDetails?>(null) }

    var showDeleteDialog by remember { mutableStateOf(false) }
    var productToDelete by remember { mutableStateOf<ProductDetails?>(null) }

    var addedProducts by remember { mutableStateOf<List<ProductDetails>>(emptyList()) }

    var searchQuery by remember { mutableStateOf("") }

    val filteredProducts = products.filter { product ->
        product.name.contains(searchQuery, ignoreCase = true) || product.description.contains(
            searchQuery,
            ignoreCase = true
        )
    }


    var showAddedProductsDialog by remember { mutableStateOf(false) }

    //todo addedProduct is a list that contains all the added products , when click on add button , it will add the product to the list
    //todo when click on notification button , it will show the list of added products
    //todo after clicking on notification button , it will clear the list of added products


    val context = LocalContext.current

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.75f)
                    .fillMaxHeight()
                    .background(Color.White)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    "User Profile",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleLarge
                )
                HorizontalDivider()
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "signUp", modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            navController.navigate("SignUpScreen")
                            scope.launch {
                                drawerState.apply {
                                    if (isClosed) open() else close()
                                }
                            }
                        })
                Text(
                    text = "signIn", modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            navController.navigate("LoginScreen")
                            scope.launch {
                                drawerState.apply {
                                    if (isClosed) open() else close()
                                }
                            }
                        })
                Text(
                    text = "Profile Screen", modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            navController.navigate("ProfileScreen")
                            scope.launch {
                                drawerState.apply {
                                    if (isClosed) open() else close()
                                }
                            }
                        })
                Text(
                    "Drawer Title",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleLarge
                )
                HorizontalDivider()
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "setting", modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            navController.navigate("SettingScreen")
                            scope.launch {
                                drawerState.apply {
                                    if (isClosed) open() else close()
                                }
                            }
                        })
            }
        },
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ProductTopBar(
                searchQuery = searchQuery,
                onSearchChange = { searchQuery = it },
                onProfileClick = { scope.launch { drawerState.apply { open() } } },
                onNotificationClick = { //todo box contains list of addedProduct
                    if (addedProducts.isNotEmpty()) {
                        showAddedProductsDialog = true
                    } else {
                        Toast.makeText(context, "No products added", Toast.LENGTH_SHORT).show()
                    }
                },
                unreadCount = addedProducts.size
            )
            if (showAddedProductsDialog) {
                AlertDialog(
                    onDismissRequest = { showAddedProductsDialog = false },
                    title = { Text("Added Products") },
                    text = {
                        Text(
                            addedProducts.joinToString("\n") { "${it.name} - ${it.price}" }
                        )
                    },
                    confirmButton = {
                        Button(onClick = {
                            addedProducts = emptyList()
                            showAddedProductsDialog = false
                        }) {
                            Text("OK")
                        }
                    }
                )
            }


            Spacer(modifier = Modifier.height(8.dp))


            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                label = { Text("Product Name") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = newPrice,
                onValueChange = { newPrice = it },
                label = { Text("Price") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = newDescription,
                onValueChange = { newDescription = it },
                label = { Text("Description") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    val price = newPrice.toDoubleOrNull()
                    if (newName.isNotBlank() && price != null) {
                        val newProduct = ProductDetails(
                            name = newName, price = price, description = newDescription
                        )
                        viewModel.insertProduct(newName, price, newDescription)
//todo inja ezafe shod
                        addedProducts = addedProducts + newProduct

                        newName = ""
                        newPrice = ""
                        newDescription = ""

                        Toast.makeText(context, "${newProduct.name} added successfully", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Please enter valid product info", Toast.LENGTH_SHORT).show()
                    }

                }, modifier = Modifier.fillMaxWidth()
            ) {
                Text("Add Product")
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                items(filteredProducts) { product ->
                    ProductCard(product = product, onEdit = {
                        productToEdit = product
                        showEditDialog = true
                    }, onDelete = {
                        productToDelete = product
                        showDeleteDialog = true
                    })
                }
            }
        }



        if (showEditDialog && productToEdit != null) {
            EditProductDialog(
                product = productToEdit!!,
                onDismiss = { showEditDialog = false },
                onUpdate = { updated ->
                    viewModel.updateProduct(updated) // ✅ Use update, not insert
                    showEditDialog = false
                })
        }

        if (showDeleteDialog && productToDelete != null) {
            DeleteConfirmationDialog(onDismiss = { showDeleteDialog = false }, onConfirmDelete = {
                viewModel.deleteProduct(productToDelete!!) // ✅ Now it deletes
                showDeleteDialog = false
                productToDelete = null
            })
        }
    }
}



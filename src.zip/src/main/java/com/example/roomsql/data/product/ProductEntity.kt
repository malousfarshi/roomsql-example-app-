package com.example.roomsql.data.product

import androidx.room.Entity
import androidx.room.PrimaryKey



//Create 3
/**
 * 💡 Entity: This is the actual table in the database.
 * TEACHING POINT: Explain that @Entity maps the Kotlin class to a SQL table.
 * The variables inside are the columns of that table.
 */
// The TodoItem data class now includes a description field.



@Entity(tableName = "table_product_detail")
data class ProductDetails(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val price: Double,
    val description: String
)



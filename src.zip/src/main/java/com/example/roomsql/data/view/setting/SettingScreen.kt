package com.example.roomsql.data.view.setting

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.navigation.NavController

@Composable
fun SettingScreen(navController: NavController){

    Column (modifier = Modifier.fillMaxSize()){

        Text(
            text = "SettingScreen"
        )


    }

}
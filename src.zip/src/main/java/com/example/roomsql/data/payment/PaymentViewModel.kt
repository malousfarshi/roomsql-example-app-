package com.example.roomsql.data.payment

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.roomsql.data.database.AppDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class PaymentViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: PaymentRepository
    val allPayments: Flow<List<PaymentRecords>>

    init {
        val paymentDao = AppDatabase.Companion.getDatabase(application).paymentDao()
        repository = PaymentRepository(paymentDao)
        allPayments = repository.allPayments
    }

    fun insertPayment(userId: Int, productId: Int, amountPaid: Double, paymentDate: String) = viewModelScope.launch {
        repository.insert(PaymentRecords(userId = userId, productId = productId, amountPaid = amountPaid, paymentDate = paymentDate))
    }

    fun updatePayment(payment: PaymentRecords) = viewModelScope.launch {
        repository.update(payment)
    }

    fun deletePayment(payment: PaymentRecords) = viewModelScope.launch {
        repository.delete(payment)
    }
}

class PaymentViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PaymentViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PaymentViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

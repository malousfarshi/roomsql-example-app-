package com.example.roomsql.data.product

import kotlinx.coroutines.flow.Flow

class ProductRepository(private val productDao: ProductDao) {
    val allProducts: Flow<List<ProductDetails>> = productDao.getAllProducts()

    suspend fun insert(product: ProductDetails) {
        productDao.insert(product)
    }

    suspend fun delete(product: ProductDetails) {
        productDao.delete(product)
    }

    suspend fun update(product: ProductDetails) {
        productDao.update(product)
    }
}

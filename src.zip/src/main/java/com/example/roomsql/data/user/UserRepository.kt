package com.example.roomsql.data.user

import kotlinx.coroutines.flow.Flow

class UserRepository(private val userDao: UserDao) {
    val allUsers: Flow<List<UsersData>> = userDao.getAllUsers()


    suspend fun insert(user: UsersData) {
        userDao.insert(user)
    }

    suspend fun update(user: UsersData) {
        userDao.update(user)
    }

    suspend fun delete(user: UsersData) {
        userDao.delete(user)
    }

    suspend fun login(username: String, password: String): UsersData? {
        return userDao.login(username, password)
    }
}

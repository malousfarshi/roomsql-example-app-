package com.example.roomsql.data.product

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.roomsql.data.database.AppDatabase
import com.example.roomsql.json.JsonLoader
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.collections.forEach

class ProductViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ProductRepository
    val allProducts: Flow<List<ProductDetails>>

    init {
        val productDao = AppDatabase.getDatabase(application).productDao()
        repository = ProductRepository(productDao)
        allProducts = repository.allProducts

        preloadProducts(application)
    }

    private fun preloadProducts(context: Application) = viewModelScope.launch {
        val products = allProducts.first()
        if (products.isEmpty()) {
            val jsonProducts = JsonLoader.loadProductDetails(context)
            jsonProducts.forEach { repository.insert(it) }
        }
    }

    fun insertProduct(name: String, price: Double, description: String) = viewModelScope.launch {
        repository.insert(ProductDetails(name = name, price = price, description = description))
    }

    fun deleteProduct(product: ProductDetails) = viewModelScope.launch {
        repository.delete(product) // ✅ Use repository
    }

    fun updateProduct(product: ProductDetails) = viewModelScope.launch {
        repository.update(product) // ✅ Use repository
    }
}

class ProductViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ProductViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProductViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

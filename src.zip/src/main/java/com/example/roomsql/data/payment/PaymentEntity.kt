package com.example.roomsql.data.payment

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "table_payment_records")
data class PaymentRecords(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val productId: Int,
    val amountPaid: Double,
    val paymentDate: String
)
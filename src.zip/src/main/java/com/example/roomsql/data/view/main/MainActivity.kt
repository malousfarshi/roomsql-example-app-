package com.example.roomsql.data.view.main

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.roomsql.data.product.ProductViewModel
import com.example.roomsql.data.product.ProductViewModelFactory
import com.example.roomsql.data.user.UserViewModel
import com.example.roomsql.data.user.UserViewModelFactory
import com.example.roomsql.data.view.product.ProductScreen
import com.example.roomsql.data.view.setting.SettingScreen
import com.example.roomsql.data.view.user.LoginScreen
import com.example.roomsql.data.view.user.ProfileScreen
import com.example.roomsql.data.view.user.SignUpScreen
import com.example.roomsql.ui.theme.RoomSQLTheme
import kotlinx.serialization.descriptors.PrimitiveKind

class MainActivity : ComponentActivity() {
    companion object {
        var USER_ID: Int = 0
        lateinit var USERNAME: String
        lateinit var EMAIL: String
        lateinit var PASSWORD: String
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RoomSQLTheme {
                val navController = rememberNavController()
                NavHost(navController, startDestination = "SplashScreen") {
                    composable("SplashScreen") {
                        SplashScreen(navController)
                    }

                    composable("ProductScreen") {
                        val viewModel: ProductViewModel = viewModel(
                            factory = ProductViewModelFactory(application)
                        )
                        ProductScreen(navController, viewModel = viewModel)
                    }
                    composable("LoginScreen") {
                        val viewModel: UserViewModel = viewModel(
                            factory = UserViewModelFactory(application)
                        )
                        LoginScreen(navController, viewModel = viewModel)

                    }
                    composable ("ProfileScreen"){
                        val viewModel: UserViewModel = viewModel(
                            factory = UserViewModelFactory(application)
                        )
                        ProfileScreen(navController, viewModel = viewModel)
                    }
                    composable("SignUpScreen") {
                        val viewModel: UserViewModel = viewModel(
                            factory = UserViewModelFactory(application)
                        )
                        SignUpScreen(navController, viewModel = viewModel)

                    }
                    composable("SettingScreen") {
                        SettingScreen(navController)
                    }
                }
            }
        }
    }
}
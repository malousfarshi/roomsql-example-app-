package com.example.roomsql.data.payment

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow


@Dao
interface PaymentDao {
    @Insert
    suspend fun insert(payment: PaymentRecords)

    @Update
    suspend fun update(payment: PaymentRecords)

    @Delete
    suspend fun delete(payment: PaymentRecords)

    @Query("SELECT * FROM table_payment_records ORDER BY id ASC")
    fun getAllPayments(): Flow<List<PaymentRecords>>
}
package com.example.roomsql.data.user

import android.service.autofill.UserData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert
    suspend fun insert(user: UsersData)// signUp

    @Update
    suspend fun update(user: UsersData)// Edit user data

    @Delete
    suspend fun delete(user: UsersData)

    @Query("SELECT * FROM table_users_data ORDER BY id ASC")
    fun getAllUsers(): Flow<List<UsersData>>

    /**
     * Retrieves a single user from the table by their ID.
     * @param userId The ID of the user to retrieve.
     * @return A Flow that emits the user data.
     */
    @Query("SELECT * FROM table_users_data WHERE id = :userId")
    fun getUserById(userId: Int): Flow<UsersData>


    @Query("SELECT * FROM table_users_data WHERE username = :username AND password = :password LIMIT 1")
    suspend fun login(username: String, password: String): UsersData?

}
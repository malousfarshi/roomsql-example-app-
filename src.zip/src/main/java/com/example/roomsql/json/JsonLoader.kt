package com.example.roomsql.json

import android.content.Context
import com.example.roomsql.data.product.ProductDetails
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object JsonLoader {
    fun loadProductDetails(context: Context): List<ProductDetails> {
        val json = context.assets.open("product_detail.json").bufferedReader().use { it.readText() }
        val type = object : TypeToken<List<ProductDetails>>() {}.type
        return Gson().fromJson(json, type)
    }
}

/***

🔹 JSON Loader Purpose
1) Used only once to populate Room DB if it's empty.

2) Demonstrates how to read structured data from assets.

3) Helps understand data formats and parsing with Gson.

***/